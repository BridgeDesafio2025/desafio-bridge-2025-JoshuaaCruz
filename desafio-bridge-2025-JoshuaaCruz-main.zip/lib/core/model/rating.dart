class RatingBreakdown {
  final int stars;
  final double percentage;

  RatingBreakdown({required this.stars, required this.percentage});

  factory RatingBreakdown.fromJson(Map<String, dynamic> json) {
    return RatingBreakdown(
      stars: json['stars'],
      percentage: json['percentage'],
    );
  }
}

class Rating {
  final double averageRating;
  final int totalReviews;
  final List<RatingBreakdown> breakdown;

  Rating({
    required this.averageRating,
    required this.totalReviews,
    required this.breakdown,
  });

  factory Rating.fromJson(Map<String, dynamic> json) {
    var breakdownList = json['breakdown'] as List;
    List<RatingBreakdown> breakdownItems =
        breakdownList.map((item) => RatingBreakdown.fromJson(item)).toList();

    return Rating(
      averageRating: json['averageRating'],
      totalReviews: json['totalReviews'],
      breakdown: breakdownItems,
    );
  }
}
