import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';

class FavoriteMoviesScreen extends StatefulWidget {
  const FavoriteMoviesScreen({super.key});

  @override
  State<FavoriteMoviesScreen> createState() => _FavoriteMoviesScreenState();
}

class _FavoriteMoviesScreenState extends State<FavoriteMoviesScreen> {
  bool _isLoading = true;
  List<Medium> _favoriteMovies = [];

  @override
  void initState() {
    super.initState();
    _fetchFavoriteDetails();
  }

  Future<void> _fetchFavoriteDetails() async {
    final prefs = await SharedPreferences.getInstance();
    final favoriteIds = prefs.getStringList('favorite_ids') ?? [];
    print('Lendo IDs de favoritos do disco: $favoriteIds');

    if (favoriteIds.isEmpty) {
      if (mounted) setState(() => _isLoading = false);
      return;
    }

    try {
      final allMediaItems = await getAllMedia();
      print('Total de itens buscados da API: ${allMediaItems.length}');

      final favoriteMoviesList = allMediaItems.where((medium) {
        return favoriteIds.contains(medium.id.toString());
      }).toList();
      print(
          'Filmes favoritados encontrados após o filtro: ${favoriteMoviesList.length}');

      if (mounted) {
        setState(() {
          _favoriteMovies = favoriteMoviesList;
          _isLoading = false;
        });
      }
    } catch (e) {
      print('### ERRO AO BUSCAR TODOS OS MÍDIAS: $e ###');
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Meus Favoritos'),
        backgroundColor: AppTheme.primaryDark,
        elevation: 0,
        automaticallyImplyLeading: false,
      ),
      backgroundColor: AppTheme.primaryDark,
      body: _buildContent(),
    );
  }

  Widget _buildContent() {
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator());
    }

    if (_favoriteMovies.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.favorite_border, size: 80, color: AppTheme.mutedText),
            SizedBox(height: 3.h),
            Text(
              'Sua lista está vazia',
              style: AppTheme.darkTheme.textTheme.titleLarge?.copyWith(
                color: AppTheme.contentWhite,
              ),
            ),
            SizedBox(height: 1.h),
            Text(
              'Adicione filmes e séries aos seus favoritos.',
              style: AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
                color: AppTheme.mutedText,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: EdgeInsets.all(4.w),
      itemCount: _favoriteMovies.length,
      itemBuilder: (context, index) {
        final medium = _favoriteMovies[index];
        return Card(
          color: AppTheme.secondaryDark,
          margin: EdgeInsets.only(bottom: 2.h),
          child: ListTile(
            leading: SizedBox(
              width: 15.w,
              child: CustomImageWidget(imageUrl: medium.poster ?? ''),
            ),
            title: Text(medium.title,
                style: TextStyle(color: AppTheme.contentWhite)),
            subtitle: Text(medium.year.toString(),
                style: TextStyle(color: AppTheme.mutedText)),
            onTap: () {
              Navigator.pushNamed(context, AppRoutes.contentDetail,
                  arguments: medium);
            },
          ),
        );
      },
    );
  }
}
