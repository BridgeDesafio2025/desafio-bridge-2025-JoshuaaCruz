import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/action_buttons_widget.dart';
import './widgets/cast_section_widget.dart';
import './widgets/genre_chips_widget.dart';
import './widgets/hero_section_widget.dart';
import './widgets/streaming_platforms_widget.dart';
import './widgets/synopsis_section_widget.dart';
import './widgets/user_ratings_widget.dart';

class ContentDetailScreen extends StatefulWidget {
  final Medium medium;

  const ContentDetailScreen({
    super.key,
    required this.medium,
  });

  @override
  State<ContentDetailScreen> createState() => _ContentDetailScreenState();
}

class _ContentDetailScreenState extends State<ContentDetailScreen> {
  bool _isFavorite = false;

  @override
  void initState() {
    super.initState();
    _loadFavoriteStatus();
  }

  Future<void> _loadFavoriteStatus() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    final favoriteIds = prefs.getStringList('favorite_ids') ?? [];
    setState(() {
      _isFavorite = favoriteIds.contains(widget.medium.id.toString());
    });
  }

  Future<void> _toggleFavorite() async {
    final prefs = await SharedPreferences.getInstance();
    final favoriteIds = prefs.getStringList('favorite_ids') ?? [];

    if (_isFavorite) {
      favoriteIds.remove(widget.medium.id.toString());
    } else {
      favoriteIds.add(widget.medium.id.toString());
    }

    await prefs.setStringList('favorite_ids', favoriteIds);

    if (mounted) {
      setState(() {
        _isFavorite = !_isFavorite;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.primaryDark,
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            backgroundColor: AppTheme.primaryDark.withValues(alpha: 0.95),
            elevation: 0,
            pinned: true,
            title: Text(widget.medium.title),
            actions: [
              IconButton(
                icon: Icon(
                  _isFavorite ? Icons.favorite : Icons.favorite_border,
                  color: _isFavorite ? Colors.red : AppTheme.contentWhite,
                  size: 24,
                ),
                onPressed: _toggleFavorite,
              ),
              IconButton(
                icon: Icon(Icons.share, color: AppTheme.contentWhite, size: 24),
                onPressed: () {},
              ),
              SizedBox(width: 2.w),
            ],
            leading: IconButton(
              icon: Icon(Icons.arrow_back_ios, color: AppTheme.contentWhite),
              onPressed: () => Navigator.pop(context),
            ),
          ),
          SliverToBoxAdapter(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                HeroSectionWidget(contentData: widget.medium),
                GenreChipsWidget(genres: widget.medium.genres),
                SynopsisSectionWidget(synopsis: widget.medium.synopsis),
                SizedBox(height: 2.h),
                CastSectionWidget(mediumId: widget.medium.id),
                SizedBox(height: 2.h),
                StreamingPlatformsWidget(platforms: widget.medium.strPlatform),
                SizedBox(height: 2.h),
                UserRatingsWidget(mediumId: widget.medium.id),
                SizedBox(height: 2.h),
                ActionButtonsWidget(
                  isInWatchlist: _isFavorite,
                  onWatchlistToggle: _toggleFavorite,
                  onShare: () {},
                ),
                SizedBox(height: 4.h),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
